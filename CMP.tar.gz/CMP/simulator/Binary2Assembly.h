/***************************************************

	File: Binary2Assembly.h

	Author: PinYo

***************************************************/
#ifndef Binary2Assembly_h
#define Binary2Assembly_h

void Binary2Assembly();

#endif