/***************************************************

	File: Execution.h

	Author: PinYo

***************************************************/

#ifndef Execution_h
#define Execution_h

#include "Instruction.h"

void Execute(Instruction);

#endif